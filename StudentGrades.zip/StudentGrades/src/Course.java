import java.util.ArrayList;

public class Course { // public class for course. 

	private String courseCode;
	private int courseCodeNumber;
	private String courseTitle;
	private int creditHours;
	private ArrayList<Grade> grades;
	private ArrayList<Student> students;
	
	public Course(String courseCode, int courseCodeNumber, String courseTitle, int creditHours) {
	
		this.courseCode = courseCode;
		this.courseCodeNumber = courseCodeNumber;
		this.courseTitle = courseTitle;
		this.creditHours = creditHours;
		this.grades = new ArrayList<>();
		this.students = new ArrayList<>();
	
	}
	// this method is to add the Student and grade. 
	public void add(Student student, Grade grade) {
		
		this.students.add(student);
		this.grades.add(grade);
		
	}
    //this method is to get the array of grades and get the grades. 
	public ArrayList<Grade> getGrades() {
	
		return grades;
	
	}
    // get information from the array of students. 
	public ArrayList<Student> getStudents() {
	
		return students;
	
	}
	
    // this method is to get the course code 
	public String getCourseCode() {
	
		return courseCode;
	
	}
	
    // this method is to get the course code number
	public int getCourseCodeNumber() {
		
		return courseCodeNumber;
		
	}
    
    // this method is to get the course title.
	public String getCourseTitle() {
	
		return courseTitle;
	
	}

    // this method is to get the credit hours per class.
	public int getCreditHours() {
	
		return creditHours;
	
	}
	
    // this method method is utilized get tokens when the lenght is 6. 
	public static Course parseCourse(String[] tokens) {
		
		if(tokens.length == 6) {
			
			try {
				
				return new Course(tokens[2], Integer.parseInt(tokens[3]),
						tokens[4], Integer.parseInt(tokens[5]));
				
			} catch (Exception e) {
				return null;
			}
			
		}
		return null;
		
	}
	
	@Override // this boolean has an if statement to check object and if they are equal to. 
	public boolean equals(Object obj) {
		
		if(obj instanceof Course) {
			
			Course course = (Course) obj;
			return this.courseCode.equals(course.courseCode) &&
					this.courseCodeNumber == course.courseCodeNumber;
			
		} 
		return false;
		
	}
	// this method is to add the course code, title, and hours alligned with proper spacing. 
	@Override
	public String toString() {
		
		return courseCode + " " + courseTitle + " " + creditHours;
		
	}
	
}
