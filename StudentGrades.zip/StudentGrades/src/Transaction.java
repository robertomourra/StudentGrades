
public class Transaction {
	private String firstName;
	private String lastName;
	private String courseCode;
	private int courseCodeNumber;
	private String gradeName;
	private String semesterCode;


	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public int getCourseCodeNumber() {
		return courseCodeNumber;
	}
	public void setCourseCodeNumber(int courseCodeNumber) {
		this.courseCodeNumber = courseCodeNumber;
	}
	public String getGradeName() {
		return gradeName;
	}
	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	public String getSemesterCode() {
		return semesterCode;
	}
	public void setSemesterCode(String semesterCode) {
		this.semesterCode = semesterCode;
	}
	 
}
