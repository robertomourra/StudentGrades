import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Scanner;

public class MySQLDatabase { // this class holds all of the user input.

	private ArrayList<String> transactions;
	private ArrayList<Transaction> transactionObjs;
	private ArrayList<Student> students;
	private ArrayList<Course> courses;
	private ArrayList<Grade> grades;
	private ArrayList<Semester> semesters; 
	// DB RELATED SETTINGS
	private String url = "jdbc:mysql://localhost:3306/studentdb?useSSL=false";
	private String user = "student101";
	private String password = "abc123";
	private String query = "SELECT VERSION()";
    private String db = "student_db";
	private String server = "localhost";
	private int port = 3306;
    private Connection connection;
    // GETTERS AND SETTERS FOR DATABASE WORK
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDb() {
		return db;
	}
	public void setDb(String db) {
		this.db = db;
	}
	
	
	// THIS METHOD CONNECTS TO DATABASE AND RETURNS TRUE IF CONNECTED SUCCESSFULLY
	public boolean connect()
	{
		url= String.format("jdbc:mysql://%s:%d/%s?useSSL=false", server, port, db);
		boolean connected = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 try  {
			  connection = DriverManager.getConnection(url, user, password);
	           connected=true;
		 } catch (SQLException ex) {
			 System.out.println(String.format("Could not connect to db %s at %s:%s using username: %s password: %s", 
		        		db, server, port, user, password));
		 } 
		return connected;
	}
	// constructor
	public MySQLDatabase() {
		
		this.transactions = new ArrayList<>();
		this.courses = new ArrayList<>();
		this.grades = new ArrayList<>();
		this.semesters = new ArrayList<>();
		this.students = new ArrayList<>();
		this.transactionObjs = new ArrayList<Transaction>();
		 
		
	}
	// execute delete request
	// remvoe record from arraylist and databaes
	public void executeDeleteRequest(String line)
	{
		// split the input string
		String[] tokens = line.split(" ");
		switch(tokens[0]) {
		case "d":
		case "D":
			// extract first name and last name
			String lastName = tokens[1];
			String firstName = tokens[2];
			// iterate through all students
			for(Iterator<Student> iterator = students.iterator(); iterator.hasNext();) {
				Student std = iterator.next();
				// if student is found
				if(std.getFirstName().equals(firstName) &&
						std.getLastName().equals(lastName)) {
					// remove from array list
					iterator.remove();
					// iterate through all transactions
					for(Iterator<Transaction> transactionIterator = this.transactionObjs.iterator(); iterator.hasNext();)
					{
						Transaction transaction = transactionIterator.next();
						if(transaction.getFirstName().equals(firstName)  && transaction.getLastName().equals(lastName))
						{
							// transaction for that student is found. remove it
							iterator.remove();
						}
					}
					String query = String.format("DELETE FROM student where first_name='%s' AND last_name='%s'",
								firstName, lastName);
					Statement st;
					try {
						// remove that student information ffrom db.
						st = this.connection.createStatement();
						st.execute(query);
						query = String.format("DELETE FROM transactions where first_name='%s' AND last_name='%s'",
									firstName, lastName);
						st.execute(query);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
			break;
		}
	}
	// this are the possible cases that the user can input.
	public void executeAddRequest(String line) {
		
		if(!transactions.contains(line)) {
		
			transactions.add(line);
			String[] tokens = line.split(" ");
			switch(tokens[1]) {

			case "c":			
			case "C":
				Course course = Course.parseCourse(tokens);
				if(course != null) {
					if(this.courses.contains(course))
					{
						System.out.println("Course Already Exist..");
					}
					else
					{
						this.courses.add(course);
						this.saveCourceToDb(course);
					}
					
				}
				break;

			case "g":			
			case "G":
				Grade grade = Grade.parseGrade(tokens);
				if(grade != null) {
					if(this.grades.contains(grade))
					{
						// avoid duplicates
						System.out.println("Grade already exist");
					}
					else
					{
						this.grades.add(grade);
						// ssave to db as welll
						this.saveGradeToDb(grade);
					}
					
				}
				break;

			case "m":			
			case "M":
				Semester semester = Semester.parseSemester(tokens);
				if(semester != null) {
					if(this.semesters.contains(semester))
					{
						System.out.println("Semester already exist");
					}
					else
					{
						this.semesters.add(semester);
						this.saveSemesterToDb(semester);
					}
					
				}
				break;

			case "s":			
			case "S":
				Student student = Student.parseStudent(tokens);
				
				if(student != null) {
					if(this.students.contains(student))
					{
						System.out.println("Student already exist..");
					}
					else
					{
						this.students.add(student);
						this.saveStudentToDb(student);
					}
				}
				break;

			case "t":			
			case "T":
				
				String lastName = tokens[2];
				String firstName = tokens[3];
				String courseCode = tokens[4];
				int courseCodeNumber = Integer.parseInt(tokens[5]);
				String gradeName = tokens[6];
				String semesterCode = tokens[7];
				
				boolean alreadyExist = false;
				// check if transaction already exist
				for(Transaction transaction: this.transactionObjs)
				{
					if(transaction.getFirstName().equals(firstName) && transaction.getLastName().equals(lastName) &&
							transaction.getCourseCode().equals(courseCode) && transaction.getCourseCodeNumber()==courseCodeNumber &&
							transaction.getGradeName().equals(gradeName) && transaction.getSemesterCode().equals(semesterCode)
							)
					{
						// transacction already found
						alreadyExist = true;
						break;
					}
						
				}
				if(alreadyExist)
				{
					// avoid duplicate
					System.out.println("Transaction already exist!");
				}
				else
				{
					// add new transaction and ave to db.
					Transaction transaction = new Transaction();
					transaction.setCourseCode(courseCode);
					transaction.setCourseCodeNumber(courseCodeNumber);
					transaction.setFirstName(firstName);
					transaction.setLastName(lastName);
					transaction.setGradeName(gradeName);
					transaction.setSemesterCode(semesterCode); 
					this.transactionObjs.add(transaction);
					// Finding name.
					Student stdObj = null;
					Course corObj = null;
					Grade grObj = null;
					for(Student std: students) {
						if(std.getFirstName().equals(firstName) &&
								std.getLastName().equals(lastName)) {
							stdObj = std;
						}
					}
					for(Course cor: courses) {
						if(cor.getCourseCode().equals(courseCode) &&
								cor.getCourseCodeNumber() == courseCodeNumber) {
							corObj = cor;
						}
					}
					for(Grade gr: grades) {
						if(gr.getGradeName().equals(gradeName)) {
							grObj = gr;
						}
					}
					for(int i = 0; i < semesters.size(); i++) {
						if(semesters.get(i).getSemesterCode().equals(semesterCode)) {
							
							// adding in semester.
							if(!semesters.get(i).getCourses().contains(corObj)) {
								
								this.semesters.get(i).addCourse(new Course(corObj.getCourseCode(), corObj.getCourseCodeNumber(),
										corObj.getCourseTitle(), corObj.getCreditHours()));
								 
								this.semesters.get(i).getCourses().get(this.semesters.get(i).getCourses().size() - 1).add(stdObj, grObj);
								this.saveTransaction(semesters.get(i), corObj, stdObj, grObj);
								
							} else {
								
								for(int j = 0; j < semesters.get(i).getCourses().size(); j++) {
									
									if(this.semesters.get(i).getCourses().get(j).equals(corObj)) {

										this.semesters.get(i).getCourses().get(j).add(stdObj, grObj);
										this.saveTransaction(semesters.get(i), corObj, stdObj, grObj);
									}
									
								}
								
							}
							
						}
					}
				}
				
				break;
			
			}
		
		}
		else
		{
			System.out.println("Duplicate Record/Operation...");
		}
		
	}
	 
	 // method to save course to db
	public void saveCourceToDb(Course course)
	{
		Statement st;
		try {
			st = connection.createStatement(); 
			String query = String.format("INSERT INTO course (code, code_number, title, credit_hours) VALUES ('%s', %d, '%s', %d)",
				course.getCourseCode(), course.getCourseCodeNumber(), course.getCourseTitle(), course.getCreditHours());
			st.execute(query);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// save transaction to db
	public void saveTransaction(Semester semester, Course course, Student student, Grade grade)
	{
		Statement st;
		try {
			st = connection.createStatement(); 
			String query = String.format("INSERT INTO transactions (first_name, last_name, course_code, course_code_number, grade_name, semester_code) VALUES ('%s', '%s', '%s', %s, '%s', '%s')",
					student.getFirstName(), student.getLastName(), course.getCourseCode(), course.getCourseCodeNumber(), grade.getGradeName(), semester.getSemesterCode() );
			st.execute(query);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 
	
	// save grade to db
	public void saveGradeToDb(Grade grade)
	{
		Statement st;
		try {
			st = connection.createStatement(); 
			String query = String.format("INSERT INTO grade (grade_name, grade) VALUES ('%s', %f)",
				grade.getGradeName(), grade.getGrade());
			st.execute(query);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// save student to db.
	public void saveStudentToDb(Student student)
	{
		Statement st;
		try {
			st = connection.createStatement(); 
			String query = String.format("INSERT INTO student (first_name, last_name, phone) VALUES ('%s', '%s', '%s')",
				student.getFirstName(), student.getLastName(), student.getPhone());
			st.execute(query);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// save semester to db
	public void saveSemesterToDb(Semester semester)
	{
		Statement st;
		try {
			st = connection.createStatement(); 
			String query = String.format("INSERT INTO semester (code, year, season) VALUES ('%s', %d, '%s')",
				semester.getSemesterCode(), semester.getYear(), semester.getSeason());
			st.execute(query);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
// load all info from db
	void loadFromDatabase()
	{
		try  {
			  
				// create SQL statement
	            Statement st = connection.createStatement();
	            // create query
	            String query = "SELECT * FROM student";
	            // execute query and fetch result set from database
	            ResultSet rs = st.executeQuery(query);
	            // iterate until result set has some data
	            while (rs.next()) {
	            	// extract information
		            	String firstName = rs.getString(1);
		            	String lastName = rs.getString(2);
		            	String phone = rs.getString(3);
		            	// create setudent and add it to array list
		                Student student = new Student(firstName, lastName, phone);
		                students.add(student);
		            }
	            // same process for course, grade, semester and transaction
		      query = "SELECT * FROM course";
		      rs = st.executeQuery(query);
		      while(rs.next())
		      {
		    	  String code = rs.getString(1);
		    	  int number = rs.getInt(2);
		    	  String title = rs.getString(3);
		    	  int credit = rs.getInt(4);
		    	  Course course = new Course(code, number, title, credit);
		    	  this.courses.add(course);
		      }
		      query = "SELECT * FROM grade";
		      rs = st.executeQuery(query);
		      while(rs.next())
		      {
		    	  String gradeName = rs.getString(1);
		    	  int grade = rs.getInt(2);
		    	  Grade gradeObj = new Grade(gradeName, grade);
		    	  this.grades.add(gradeObj);
		      }
		      query = "SELECT * FROM semester";
		      rs = st.executeQuery(query);
		      while(rs.next())
		      {
		    	  String code = rs.getString(1);
		    	  int year = rs.getInt(2);
		    	  String season = rs.getString(3);
		    	  Semester sem = new Semester(code, year, season);
		    	  this.semesters.add(sem);
		      }
		      
		      query = "SELECT * FROM transactions";
		      rs = st.executeQuery(query);
		      while(rs.next())
		      {
		    	  // 	first_name 	last_name 	course_code_number 	grade_name 	semester_code 
		    	  String firstName = rs.getString(1);
		    	  String lastName = rs.getString(2);
		    	  String courseCodeName = rs.getString(3);
		    	  int courseCodeNumber = rs.getInt(4);
		    	  String gradeName = rs.getString(5);
		    	  String semesterCode = rs.getString(6);
		    	  Transaction transaction = new Transaction();
					transaction.setCourseCode(courseCodeName);
					transaction.setCourseCodeNumber(courseCodeNumber);
					transaction.setFirstName(firstName);
					transaction.setLastName(lastName);
					transaction.setGradeName(gradeName);
					transaction.setSemesterCode(semesterCode);
					this.transactionObjs.add(transaction);
		    	  Student stdObj = null;
					Course corObj = null;
					Grade grObj = null;
					for(Student std: students) {
						if(std.getFirstName().equals(firstName) &&
								std.getLastName().equals(lastName)) {
							stdObj = std;
						}
					}
					for(Course cor: courses) {
						if(cor.getCourseCode().equals(courseCodeName) &&
								cor.getCourseCodeNumber() == courseCodeNumber) {
							corObj = cor;
						}
					}
					for(Grade gr: grades) {
						if(gr.getGradeName().equals(gradeName)) {
							grObj = gr;
						}
					}
					for(int i = 0; i < semesters.size(); i++) {
						if(semesters.get(i).getSemesterCode().equals(semesterCode)) {
							
							// adding in semester.
							if(!semesters.get(i).getCourses().contains(corObj)) {
								
								this.semesters.get(i).addCourse(new Course(corObj.getCourseCode(), corObj.getCourseCodeNumber(),
										corObj.getCourseTitle(), corObj.getCreditHours()));
								 
								this.semesters.get(i).getCourses().get(this.semesters.get(i).getCourses().size() - 1).add(stdObj, grObj);
								 
								
							} else {
								
								for(int j = 0; j < semesters.get(i).getCourses().size(); j++) {
									
									if(this.semesters.get(i).getCourses().get(j).equals(corObj)) {

										this.semesters.get(i).getCourses().get(j).add(stdObj, grObj);
										 
									}
									
								}
								
							}
							
						}
					}
		      }
		      
		} catch (SQLException ex) {
		           
			System.out.println(String.format("Could not connect to db %s at %s:%s using username: %s password: %s", 
		   db, server, port, user, password));
		}
	}
	// this method does not return anything. It prints and splits. 
	public void executePrint(String line) {
		
		String[] tokens = line.split(" ");
		switch(tokens[1]) {

		case "c":			
		case "C":
			for(Course course: courses) {
				System.out.println(course);
			}
			break;

		case "g":			
		case "G":
			for(Grade grade: grades) {
				System.out.println(grade);
			}
			break;

		case "m":			
		case "M":
			for(Semester semester: semesters) {
				System.out.println(semester);
			}
			break;

		case "s":			
		case "S":
			for(Student student: students) {
				System.out.println(student);
			}
			break;

		case "t":			
		case "T":
			for(String transaction: transactions) {
				if(transaction.startsWith("a t"))
					System.out.println(transaction.substring(4, transaction.length()));
			}
			
		}
		
	}

	public void executePrettyPrint(String line) {

		String[] tokens = line.split(" ");
		String lastName = tokens[1];
		String firstName = tokens[2];
		// Finding name.
		Student stdObj = null;
		for(Student std: students) {
			if(std.getFirstName().equals(firstName) &&
					std.getLastName().equals(lastName)) {
				stdObj = std;
			}
		}
		int hours = 0;
		double gpa = 0;
		for(Semester semester: semesters) {
			String data = "";
			for(Course course: semester.getCourses()) {
				for(int i = 0; i < course.getStudents().size(); i++) {
					if(course.getStudents().get(i).equals(stdObj)) {
						
						data += course.getCourseCode()+course.getCourseCodeNumber() + " " +
								course.getCourseTitle() + " ("+course.getCreditHours()+") " + 
								course.getGrades().get(i).getGradeName() + "\n";
						hours += course.getCreditHours();
						gpa += (course.getGrades().get(i).getGrade() * course.getCreditHours());
						
					}
					
				}
				
			}
			if(!data.isEmpty()) {
				System.out.print("============ Semester: "+semester.getSeason()+" "+semester.getYear()+" ============\n"
						+ data);
			}
			
		}
		gpa /= hours;
		System.out.println("  STUDENT HOURS COMPLETED: "+hours);
		System.out.println("  STUDENT GPA: "+String.format("%.5f", gpa));
		
	}
	
}
