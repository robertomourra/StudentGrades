
import java.util.Scanner; 

public class Program { // class to run the program

	private Scanner scan;
	private MySQLDatabase database;
	
	public Program() {
		
		this.scan = new Scanner(System.in);
	    database = new MySQLDatabase();
	    // ask for database detailss
		System.out.println("Enter Database Host (For example 127.0.0.1)");
		this.database.setServer(this.scan.next());
		System.out.println("Enter Database Port (For example 3306) or 0 to use default port");
		int port = this.scan.nextInt();
		if(port ==0) this.database.setPort(3306);
		else this.database.setPort(port);
		System.out.println("Enter database user");
		this.database.setUser(this.scan.next());
		System.out.println("Enter database password");
		this.database.setPassword(this.scan.next());
		
		// connect to database
	    if(!database.connect())
	    	System.out.println("Could not connect to database. program will now exit");
	    else {
	    	database.loadFromDatabase();
			execute();	
	    }
	    
		
	}
	
	public void execute() { 
		
		boolean run = true;
		do {
			
			System.out.print(">>>");
			String line = scan.nextLine();
			String[] tokens = line.split(" ");
			switch(tokens[0]) {
		
			// this are all the possible user inputs. 
			case "l":
			case "L":
				this.database.executePrint(line);
				break;
				
			case "a":
			case "A":
				this.database.executeAddRequest(line);
				break;
			
			case "t":
			case "T":
				this.database.executePrettyPrint(line);
				break;
				
			case "q":
			case "Q":
				run = false;
				break;
			case "d":
			case "D":
				this.database.executeDeleteRequest(line);
				break;
			}
			 
			
		} while(run);
		
	}
	
	public static void main(String[] args) { // this the program main method.

		new Program();
		
	}

}
