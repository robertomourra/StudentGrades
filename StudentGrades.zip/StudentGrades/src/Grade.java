
public class Grade { //public class for grades.

	private String gradeName; 
	private double grade;

	public Grade(String gradeName, double grade) {

		this.gradeName = gradeName;
		this.grade = grade;
	
	}
	// method to get the grade name.
	public String getGradeName() {
	
		return gradeName;
	
	}

    // method to get the grade.
	public double getGrade() {
	
		return grade;
	
	}

    // static method to get grades when the lenght is equal 4. 
	public static Grade parseGrade(String[] tokens) {
		
		if(tokens.length == 4) {
			
			try {
				
				return new Grade(tokens[2], Double.parseDouble(tokens[3]));
				
			} catch (Exception e) {
				return null;
			}
			
		}
		return null;
		
	}
	
	@Override 
	// this boolean check objects and if they are equal to each other. 
	public boolean equals(Object obj) {
		
		if(obj instanceof Grade) {
			
			return ((Grade) obj).gradeName.equals(gradeName);
			
		} 
		return false;
		
	}
	
	@Override
    //this method prints the grade name and the grade score alligned. 
	public String toString() {
		
		return gradeName + " " + grade;
		
	}
	
}
