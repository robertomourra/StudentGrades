
public class Student { // public class for student

	private String firstName; 
	private String lastName;
	private String phone;
	
	// this method is used when printing out in these order.
	public Student(String firstName, String lastName, String phone) {
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
	
	}

	// gets the student first name.
	public String getFirstName() {

		return firstName;
	
	}

	// gets the student first name.
	public String getLastName() {

		return lastName;
	
	}

	// gets the student phone number.
	public String getPhone() {

		return phone;
	
	}

	// 
	public static Student parseStudent(String[] tokens) {
		
		if(tokens.length == 5) { // if the lenght is equal to 5, try the following: 
			
			try {
				
				return new Student(tokens[3], tokens[2], tokens[4]); // return the students name, last name, and phone num
				
			} catch (Exception e) {
				return null;
			}
			
		}
		return null;
		
	}
	
	@Override
	
	public boolean equals(Object obj) {
		
		if(obj instanceof Student) {
			
			Student student = (Student) obj;
			return student.firstName.equals(firstName) &&
					student.lastName.equals(lastName);
			
		} 
		return false;
		
	}
	
	@Override
	// this method is the final step to printing out and calling the previous methods.
	public String toString() {
		
		return lastName + ", " + firstName + " " + phone;
		
	}
	
}
