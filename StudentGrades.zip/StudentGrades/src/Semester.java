import java.util.ArrayList;

public class Semester { // public class for semester.

	private String semesterCode;
	private int year;
	private String season;
	private ArrayList<Course> courses;
	
	// this method is used when printing out in these order.
	public Semester(String semesterCode, int year, String season) {
	
		this.semesterCode = semesterCode;
		this.year = year;
		this.season = season;
		this.courses = new ArrayList<>();
	
	}
	// this method will be called to add courses. 
	public void addCourse(Course course) {
		
		this.courses.add(course);
		
	}
	// this method returns the array of courses.
	public ArrayList<Course> getCourses() {
		
		return this.courses;
		
	}
	
	//this method is used to get the semester prefix
	public String getSemesterCode() {

		return semesterCode;
	
	}

	// this method gets and returns the year.
	public int getYear() {
	
		return year;
	
	}
	
	// this method gets and returns the season.
	public String getSeason() {
	
		return season;
	
	}
	//checks if the lenght of the tokens is equal to 5 and then tries to catch and if yes, it returns. If not is null.
	public static Semester parseSemester(String[] tokens) {
		
		if(tokens.length == 5) {
			
			try {
				
				return new Semester(tokens[2], Integer.parseInt(tokens[3]), tokens[4]);
				
			} catch (Exception e) {
				return null;
			}
			
		}
		return null;
		
	}
	
	@Override
	
	// checks if the semester codes are equal. 
	public boolean equals(Object obj) {
		
		if(obj instanceof Semester) {
			
			Semester semester = (Semester) obj;
			return semester.semesterCode.equals(semesterCode);
			
		} 
		return false;
		
	}
	
	@Override
	public String toString() {
		
		return semesterCode + " " + year + " " + season;
		
	}
	
}
